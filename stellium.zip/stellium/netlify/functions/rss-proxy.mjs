const ALLOWED_HOSTS = new Set([
  'arstechnica.com',
  'axios.com',
  'dailycaller.com',
  'feeds.abcnews.com',
  'feeds.bbci.co.uk',
  'feeds.nbcnews.com',
  'moxie.foxnews.com',
  'news.google.com',
  'nypost.com',
  'phys.org',
  'rss.cnn.com',
  'rss.upi.com',
  'techcrunch.com',
  'thehill.com',
  'www.aljazeera.com',
  'www.breitbart.com',
  'www.cbsnews.com',
  'www.cbssports.com',
  'www.engadget.com',
  'www.newsmax.com',
  'www.oddee.com',
  'www.politico.com',
  'www.science.org',
  'www.sciencedaily.com',
  'www.theguardian.com',
  'www.usatoday.com',
  'www.washingtontimes.com'
]);

export default async (req) => {
  const { searchParams } = new URL(req.url);
  const feedUrl = searchParams.get('url');

  if (!feedUrl) {
    return new Response(JSON.stringify({ error: 'Missing url parameter' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  let parsed;
  try {
    parsed = new URL(feedUrl);
  } catch {
    return new Response(JSON.stringify({ error: 'Invalid URL' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  if (!ALLOWED_HOSTS.has(parsed.hostname)) {
    return new Response(JSON.stringify({ error: 'Domain not allowed' }), {
      status: 403,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const res = await fetch(feedUrl, {
      headers: { 'User-Agent': 'StelliumReport/1.0' },
      signal: AbortSignal.timeout(8000)
    });

    if (!res.ok) {
      return new Response(JSON.stringify({ error: `Upstream returned ${res.status}` }), {
        status: 502,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const body = await res.text();
    return new Response(body, {
      headers: {
        'Content-Type': 'application/xml; charset=utf-8',
        'Cache-Control': 'public, s-maxage=300, max-age=300'
      }
    });
  } catch {
    return new Response(JSON.stringify({ error: 'Failed to fetch feed' }), {
      status: 502,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};
